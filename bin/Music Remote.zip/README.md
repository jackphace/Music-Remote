Music-Remote
============

Control music players using global hotkeys you define with this Chrome extension!

To install, drag the 'Music Remote.crx' file over your 'chrome://extensions/'  tab.

To redfine your hotkeys, scroll to the bottom of 'chrome://extensions/' and select 'keyboard shortcuts' to edit.

The supported players are currently:
<ul>
<li>Amazon Cloud Player</li>
<li>Google Music</li>
<li>Grooveshark</li>
<li>Pandora</li>
<li>Youtube</li>
</ul>

The supported actions are:
<table id="compatibility-table" class="table table-hover table-bordered">
                            <thead>
                                <tr id="compatibility-actions"><th></th><th>Previous</th><th>Next</th><th>Play</th><th>Dislike</th><th>Store</th><th>Activate Tab</th></tr>
                            </thead>
                            <tbody id="compatibility-list"><tr id="Amazon-compatibility"><td>Amazon</td><td>O</td><td>O</td><td>O</td><td>X</td><td>X</td><td>O</td></tr><tr id="Google-compatibility"><td>Google</td><td>O</td><td>O</td><td>O</td><td>X</td><td>X</td><td>O</td></tr><tr id="Grooveshark-compatibility"><td>Grooveshark</td><td>O</td><td>O</td><td>O</td><td>O</td><td>O</td><td>O</td></tr><tr id="Pandora-compatibility"><td>Pandora</td><td>O</td><td>O</td><td>O</td><td>X</td><td>X</td><td>O</td></tr><tr id="Youtube-compatibility"><td>Youtube</td><td>O</td><td>O</td><td>O</td><td>X</td><td>X</td><td>O</td></tr></tbody>
                        </table>
                        

