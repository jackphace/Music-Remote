var playerMid = document.getElementsByClassName("player-middle");
var indexButton = 2;
if (playerMid && playerMid[0] && playerMid[0].children[indexButton]){
playerMid[0].children[indexButton].click()
}