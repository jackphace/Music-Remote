if (document.getElementsByClassName("ytp-button ytp-button-play").length > 0)
    document.getElementsByClassName("ytp-button ytp-button-play")[0].click();
else document.getElementsByClassName("ytp-button ytp-button-pause")[0].click();